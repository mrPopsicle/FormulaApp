package com.example.engineeringformulas_shawnsantos.model;

public class FormulaData {
    private static FormulaData instance;
    private String selectedFormula;
    private String targetVariable;

    private FormulaData() {}

    public static FormulaData getInstance() {
        if (instance == null) {
            instance = new FormulaData();
        }
        return instance;
    }

    public void setSelectedFormula(String formula, String target) {
        this.selectedFormula = formula;
        this.targetVariable = target;
    }

    public String getSelectedFormula() {
        return selectedFormula;
    }

    public String getTargetVariable() {
        return targetVariable;
    }
}