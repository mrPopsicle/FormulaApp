package com.example.engineeringformulas_shawnsantos.controller;

import com.example.engineeringformulas_shawnsantos.model.ElectricEnergy;
import com.example.engineeringformulas_shawnsantos.model.EnergyCalc;
import com.example.engineeringformulas_shawnsantos.model.FormulaData;
import com.example.engineeringformulas_shawnsantos.model.KinematicsCalc;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

public class ElectricController {
    @FXML
    private Button computeButton, clearButton;
    @FXML
    private Label label1, label2, label3, targetLabel;
    @FXML
    private TextField input1, input2, input3;
    @FXML
    private TextField resultField;
    @FXML
    private BorderPane borderPane;

    private EnergyCalc calculator;
    private String targetVariable;

    public void initialize() {
        calculator = new EnergyCalc();
        targetVariable = FormulaData.getInstance().getTargetVariable();
        resultField.setEditable(false);
        setInputHintsBasedOnTargetVariable();
    }

    @FXML
    public void onComputeButtonClick(ActionEvent event) {
        try {
            String[] values = new String[3];
            values[0] = input1.getText();
            values[1] = input2.getText();
            values[2] = input3.getText();

            double result = calculator.compute(targetVariable, values);
            resultField.setText(String.valueOf(result));
        } catch (NumberFormatException e) {
            resultField.setText("Invalid input.");
            e.printStackTrace();
        }
    }
    @FXML
    public void setInputHintsBasedOnTargetVariable() {
        if (label1 == null || label2 == null || label3 == null ||
                input1 == null || input2 == null || input3 == null ||
                targetLabel == null) {
            System.err.println("One or more FXML controls were not properly initialized");
            return;
        }

        switch (targetVariable) {
            case "electricEnergy":
                label1.setText("Time (s)");
                label2.setText("Current (A)");
                label3.setText("Voltage (V)");
                targetLabel.setText("Electric Energy (J)");
                break;
            case "time":
                label1.setText(" Current (A)");
                label2.setText(" Voltage (V)");
                label3.setText("Electric Energy (J)");
                targetLabel.setText("Time");
                break;
            case "current":
                targetLabel.setText(" Current (A)");
                label2.setText(" Voltage (V)");
                label3.setText("Electric Energy (J)");
                label1.setText("Time");
                break;
            case "voltage":
                label2.setText(" Current (A)");
                targetLabel.setText(" Voltage (V)");
                label3.setText("Electric Energy (J)");
                label1.setText("Time");
                break;
            default:
                label1.setText("Input 1");
                label2.setText("Input 2");
                label3.setText("Input 3");
                targetLabel.setText("Target Variable");
                break;
        }
    }
    @FXML
    public void onClearButtonClick(ActionEvent event) {
        input1.clear();
        input2.clear();
        input3.clear();
        resultField.clear();
    }
    @FXML
    public void onReturnClick(ActionEvent event) throws Exception {
        BorderPane pane = FXMLLoader.load(getClass().getResource("/com/example/engineeringformulas_shawnsantos/electric.fxml"));
        borderPane.getChildren().setAll(pane);
    }
}
