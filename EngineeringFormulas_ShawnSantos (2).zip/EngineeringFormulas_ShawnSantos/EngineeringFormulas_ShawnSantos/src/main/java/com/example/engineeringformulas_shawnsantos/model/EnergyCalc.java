package com.example.engineeringformulas_shawnsantos.model;

public class EnergyCalc extends ElectricEnergy {
    public EnergyCalc() {
        super(0, 0, 0, 0);
    }
}
