package com.example.engineeringformulas_shawnsantos.model;

public interface Formulas {

    public double compute(String variable, String [] values);

    public String[] getParameterList();

}
