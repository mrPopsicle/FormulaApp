package com.example.engineeringformulas_shawnsantos.model;

public abstract class ElectricEnergy implements Formulas {
    private final String[] parameterList = {"time", "electricEnergy",
            "voltage", "current"};
    private double time;
    private double electricEnergy;
    private double voltage;
    private double current;
    @Override
    public String[] getParameterList() {
        return parameterList;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public double getElectricEnergy() {
        return electricEnergy;
    }

    public void setElectricEnergy(double electricEnergy) {
        this.electricEnergy = electricEnergy;
    }

    public double getVoltage() {
        return voltage;
    }

    public void setVoltage(double voltage) {
        this.voltage = voltage;
    }

    public double getCurrent() {
        return current;
    }

    public void setCurrent(double current) {
        this.current = current;
    }

    public ElectricEnergy(double time, double electricEnergy, double voltage, double current) {
        this.time = time;
        this.electricEnergy = electricEnergy;
        this.voltage = voltage;
        this.current = current;
    }
    public void computeElectricEnergy() {
        electricEnergy = voltage * current * time;
    }
    public void computeVoltage() {
        voltage = electricEnergy/(current * time);
    }
    public void computeCurrent() {
        current = electricEnergy/(voltage * time);
    }
    public void computeTime() {
        time = electricEnergy/(voltage * current);
    }
    @Override
    public double compute(String variable, String[] values) {
        if (variable == null) {
            return 0;
        }
        if (variable.equalsIgnoreCase("electricEnergy")) {
            time = Double.parseDouble(values[0]);
            voltage = Double.parseDouble(values[1]);
            current = Double.parseDouble(values[2]);
            computeElectricEnergy();
            return electricEnergy;
        }
        else if (variable.equalsIgnoreCase("voltage")) {
            time = Double.parseDouble(values[0]);
            electricEnergy = Double.parseDouble(values[1]);
            current = Double.parseDouble(values[2]);
            computeVoltage();
            return voltage;
        }
        else if (variable.equalsIgnoreCase("current")) {
            time = Double.parseDouble(values[0]);
            electricEnergy = Double.parseDouble(values[1]);
            voltage = Double.parseDouble(values[2]);
            computeCurrent();
            return current;
        }else if (variable.equalsIgnoreCase("time")) {
            voltage = Double.parseDouble(values[0]);
            electricEnergy = Double.parseDouble(values[1]);
            current = Double.parseDouble(values[2]);
            computeTime();
            return time;
        }
        return 0;
    }

}
