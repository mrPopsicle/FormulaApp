package com.example.engineeringformulas_shawnsantos.model;

public class KinematicsCalc extends KinematicsFormula {
    public KinematicsCalc() {
        super(0, 0, 0, 0); // Initialize with zeros
    }
}