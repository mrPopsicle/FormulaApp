package com.example.engineeringformulas_shawnsantos.model;

public abstract class KinematicsFormula implements Formulas {
    private final String[] parameterList = {"angularAcceleration", "iAngularVelocity",
            "fAngularVelocity", "time"};
    private double angularAcceleration;
    private double iAngularVelocity;
    private double fAngularVelocity;
    private double time;

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public double getfAngularVelocity() {
        return fAngularVelocity;
    }

    public void setfAngularVelocity(double fAngularVelocity) {
        this.fAngularVelocity = fAngularVelocity;
    }

    public double getiAngularVelocity() {
        return iAngularVelocity;
    }

    public void setiAngularVelocity(double iAngularVelocity) {
        this.iAngularVelocity = iAngularVelocity;
    }

    public double getAngularAcceleration() {
        return angularAcceleration;
    }

    public void setAngularAcceleration(double angularAcceleration) {
        this.angularAcceleration = angularAcceleration;
    }

    @Override
    public String[] getParameterList() {
        return parameterList;
    }

    public KinematicsFormula(double angularAcceleration, double initialAngularVelocity, double fAngularVelocity, double time) {
        this.angularAcceleration = angularAcceleration;
        this.iAngularVelocity = initialAngularVelocity;
        this.fAngularVelocity = fAngularVelocity;
        this.time = time;
    }

    public void computeFinalAngularVelocity() {
        fAngularVelocity = iAngularVelocity + angularAcceleration * time;
    }

    public void computeAngularAcceleration() {
        angularAcceleration = (fAngularVelocity - iAngularVelocity) / time;
    }

    public void computeInitialAngularVelocity() {
        iAngularVelocity = fAngularVelocity - angularAcceleration * time;
    }

    public void computeTime() {
        time = (fAngularVelocity - iAngularVelocity) / angularAcceleration;
    }

    @Override
    public double compute(String variable, String[] values) {
        if (variable == null) {
            return 0;
        }
        if (variable.equalsIgnoreCase("angularAcceleration")) {
            time = Double.parseDouble(values[0]);
            fAngularVelocity = Double.parseDouble(values[1]);
            iAngularVelocity = Double.parseDouble(values[2]);
            computeAngularAcceleration();
            return angularAcceleration;
        }
        else if (variable.equalsIgnoreCase("iAngularVelocity")) {
            time = Double.parseDouble(values[0]);
            fAngularVelocity = Double.parseDouble(values[1]);
            angularAcceleration = Double.parseDouble(values[2]);
            computeInitialAngularVelocity();
            return iAngularVelocity;
        }
        else if (variable.equalsIgnoreCase("fAngularVelocity")) {
            time = Double.parseDouble(values[0]);
            iAngularVelocity = Double.parseDouble(values[1]);
            angularAcceleration = Double.parseDouble(values[2]);
            computeFinalAngularVelocity();
            return fAngularVelocity;
        }else if (variable.equalsIgnoreCase("time")) {
            angularAcceleration = Double.parseDouble(values[0]);
            fAngularVelocity = Double.parseDouble(values[1]);
            iAngularVelocity = Double.parseDouble(values[2]);
            computeTime();
            return time;
        }
        return 0;
    }
}
