package com.example.engineeringformulas_shawnsantos.controller;

import com.example.engineeringformulas_shawnsantos.HelloApplication;
import com.example.engineeringformulas_shawnsantos.model.FormulaData;
import com.example.engineeringformulas_shawnsantos.model.KinematicsCalc;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;

public class MenuController {

    @FXML
    private Label welcomeText;
    @FXML
    private BorderPane borderPane;


    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to Shawn Application!");
    }

    //Main Functionalities
    @FXML
    protected void onExitButtonClick(ActionEvent event) {
        Platform.exit();
    }

    @FXML
    protected void onKinematicsClick(ActionEvent event) throws IOException {
        BorderPane pane = FXMLLoader.load(getClass().getResource("/com/example/engineeringformulas_shawnsantos/kinematics.fxml"));
        borderPane.getChildren().setAll(pane);
    }

    @FXML
    protected void onElectricEnergyClick(ActionEvent event) throws IOException {
        BorderPane pane = FXMLLoader.load(getClass().getResource("/com/example/engineeringformulas_shawnsantos/electric.fxml"));
        borderPane.getChildren().setAll(pane);
    }

    @FXML
    protected void onReturnClick(ActionEvent event) throws IOException {
        BorderPane pane = FXMLLoader.load(getClass().getResource("/com/example/engineeringformulas_shawnsantos/menu.fxml"));
        borderPane.getChildren().setAll(pane);
    }

    //Kinematics
    @FXML
    protected void onFinalAngularVelocityClick(ActionEvent event) throws IOException {
        FormulaData.getInstance().setSelectedFormula("Find final angular velocity", "fAngularVelocity");
        loadCalculationPage();
    }

    @FXML
    protected void onInitialAngularVelocityClick(ActionEvent event) throws IOException {
        FormulaData.getInstance().setSelectedFormula("Find initial angular velocity", "iAngularVelocity");
        loadCalculationPage();
    }

    @FXML
    protected void onAngularAccelerationClick(ActionEvent event) throws IOException {
        FormulaData.getInstance().setSelectedFormula("Find angular acceleration", "angularAcceleration");
        loadCalculationPage();
    }

    @FXML
    protected void onFindTimeClick(ActionEvent event) throws IOException {
        FormulaData.getInstance().setSelectedFormula("Find time", "time");
        loadCalculationPage();
    }

    //Electric
    @FXML
    protected void onFindElectricEnergyClick(ActionEvent event) throws IOException {
        FormulaData.getInstance().setSelectedFormula("Find electric energy", "electricEnergy");
        loadCalculationPageElectric();
    }
    @FXML
    protected void onFindVoltageClick(ActionEvent event) throws IOException {
        FormulaData.getInstance().setSelectedFormula("Find voltage", "voltage");
        loadCalculationPageElectric();
    }
    @FXML
    protected void onFindCurrentClick(ActionEvent event) throws IOException {
        FormulaData.getInstance().setSelectedFormula("Find current", "current");
        loadCalculationPageElectric();
    }
    @FXML
    protected void onFindElectricTime(ActionEvent event) throws IOException {
        FormulaData.getInstance().setSelectedFormula("Find electric time", "time");
        loadCalculationPageElectric();
    }

    private void loadCalculationPageElectric() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/engineeringformulas_shawnsantos/electricFormula.fxml"));
        BorderPane pane = loader.load();
        borderPane.getChildren().setAll(pane);
    }
    private void loadCalculationPage() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/engineeringformulas_shawnsantos/kinematicsFormula.fxml"));
        BorderPane pane = loader.load();
        borderPane.getChildren().setAll(pane);
    }
}
