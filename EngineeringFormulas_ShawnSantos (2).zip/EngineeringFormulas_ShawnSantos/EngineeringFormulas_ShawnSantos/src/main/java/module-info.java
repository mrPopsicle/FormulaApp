module com.example.engineeringformulas_shawnsantos {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.engineeringformulas_shawnsantos to javafx.fxml;
    exports com.example.engineeringformulas_shawnsantos;
    exports com.example.engineeringformulas_shawnsantos.controller;
    opens com.example.engineeringformulas_shawnsantos.controller to javafx.fxml;
    exports com.example.engineeringformulas_shawnsantos.model;
    opens com.example.engineeringformulas_shawnsantos.model to javafx.fxml;
}